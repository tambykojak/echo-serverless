
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tambykojak',
  applicationName: 'echo-serverless',
  appUid: 'NWdxgCdh9TRwC2v2h5',
  orgUid: 'c5b03565-8500-41b8-85d8-b2d4f44d87d6',
  deploymentUid: 'fe987e09-4056-4587-8a32-cbcab70db64c',
  serviceName: 'echo-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'echo-serverless-dev-api', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}